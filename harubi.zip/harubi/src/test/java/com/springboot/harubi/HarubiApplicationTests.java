package com.springboot.harubi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HarubiApplicationTests {

	@Test
	void contextLoads() {
	}

}
