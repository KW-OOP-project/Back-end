package com.springboot.harubi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HarubiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HarubiApplication.class, args);
	}

}
